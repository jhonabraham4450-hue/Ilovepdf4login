iLovePDF4 Login system
1. Create a Cloudflare D1 database named ilovepdf4-users.
2. Run schema.sql in D1 Console.
3. Replace PASTE_D1_DATABASE_ID_HERE in wrangler.jsonc.
4. Set ADMIN_PASSWORD as a secret/environment variable.
5. Deploy through Git or Wrangler. Direct Upload does not deploy Pages Functions.
6. After deploy, /login.html is the login page; /admin.html is the admin panel.
