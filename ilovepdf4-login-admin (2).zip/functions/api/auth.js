const enc=new TextEncoder(), dec=new TextDecoder();
function b64(a){return btoa(String.fromCharCode(...new Uint8Array(a))).replaceAll('+','-').replaceAll('/','_').replaceAll('=','')}
function unb64(s){s=s.replaceAll('-','+').replaceAll('_','/');while(s.length%4)s+='=';return Uint8Array.from(atob(s),c=>c.charCodeAt(0))}
async function hash(p,salt){let k=await crypto.subtle.importKey('raw',enc.encode(p),'PBKDF2',false,['deriveBits']);let bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:120000,hash:'SHA-256'},k,256);return b64(bits)}
async function req(c){try{return await c.request.json()}catch{return {}}}
function cookie(name,val,max=86400*7){return `${name}=${val}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${max}`}
async function user(c,username,password){let r=await c.env.DB.prepare('SELECT * FROM users WHERE username=?').bind(username).first();if(!r)return false;return (await hash(password,unb64(r.salt)))===r.password_hash}
export async function onRequestPost(c){
 let path=new URL(c.request.url).pathname,x=await req(c);
 if(path==='/api/register'){let u=(x.username||'').trim().toLowerCase(),p=x.password||'';if(!/^[a-z0-9_]{3,30}$/.test(u))return Response.json({ok:false,error:'User ID 3-30 characters: a-z, 0-9, _'});if(p.length<6)return Response.json({ok:false,error:'Password কমপক্ষে 6 characters'});let old=await c.env.DB.prepare('SELECT id FROM users WHERE username=?').bind(u).first();if(old)return Response.json({ok:false,error:'এই User ID already আছে'});let salt=crypto.getRandomValues(new Uint8Array(16)),h=await hash(p,salt);await c.env.DB.prepare('INSERT INTO users(username,password_hash,salt,created_at) VALUES(?,?,?,?)').bind(u,h,b64(salt),new Date().toISOString()).run();return Response.json({ok:true})}
 if(path==='/api/login'){let u=(x.username||'').trim().toLowerCase(),p=x.password||'';if(!(await user(c,u,p)))return Response.json({ok:false,error:'User ID বা Password ভুল'});let token=b64(crypto.getRandomValues(new Uint8Array(32)));await c.env.DB.prepare('INSERT INTO sessions(token,username,expires_at) VALUES(?,?,?)').bind(token,u,Date.now()+604800000).run();return new Response(JSON.stringify({ok:true}),{headers:{'Content-Type':'application/json','Set-Cookie':cookie('session',token)}})}
 if(path==='/api/logout')return new Response(JSON.stringify({ok:true}),{headers:{'Content-Type':'application/json','Set-Cookie':cookie('session','',0)}})
 if(path==='/api/admin-login'){if(x.username!==c.env.ADMIN_USER||x.password!==c.env.ADMIN_PASSWORD)return Response.json({ok:false,error:'Admin credentials ভুল'});return new Response(JSON.stringify({ok:true}),{headers:{'Content-Type':'application/json','Set-Cookie':cookie('admin','1')}})}
 return Response.json({ok:false,error:'Not found'},{status:404})
}
export async function onRequestGet(c){
 let path=new URL(c.request.url).pathname;
 if(path==='/api/me'){let tok=(c.request.headers.get('Cookie')||'').match(/(?:^|;\s*)session=([^;]+)/)?.[1];let r=tok?await c.env.DB.prepare('SELECT username FROM sessions WHERE token=? AND expires_at>?').bind(tok,Date.now()).first():null;return Response.json(r?{ok:true,username:r.username}:{ok:false})}
 if(path==='/api/admin-users'){let ok=(c.request.headers.get('Cookie')||'').includes('admin=1');if(!ok)return Response.json({ok:false},{status:401});let r=await c.env.DB.prepare('SELECT username,created_at FROM users ORDER BY id DESC').all();return Response.json({ok:true,users:r.results})}
 return new Response('Not found',{status:404})
}