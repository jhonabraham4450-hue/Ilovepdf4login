iLovePDF4 — Login + User + Admin + PDF Tools

1. Create a Cloudflare D1 database named ilovepdf4-users.
2. Run schema.sql in the D1 Console.
3. Put the real D1 database ID in wrangler.jsonc.
4. Set ADMIN_PASSWORD as a Cloudflare secret. ADMIN_USER defaults to admin.
5. Deploy with Git integration or Wrangler. Do not use Pages Direct Upload because Pages Functions must be deployed.
6. /login.html = user Login/Register
7. /home.html = protected user dashboard
8. /admin.html = protected admin panel

Included browser-side tools:
- Image to PDF
- Merge PDF
- Split PDF (extract one page)

Word/PDF, Excel/PDF and PowerPoint/PDF conversions need a server-side office/PDF conversion engine or external API. This package does not include an API key or pretend those conversions are connected.
