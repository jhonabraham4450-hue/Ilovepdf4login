const enc=new TextEncoder();
function b64(a){return btoa(String.fromCharCode(...new Uint8Array(a))).replaceAll('+','-').replaceAll('/','_').replaceAll('=','')}
function unb64(s){s=s.replaceAll('-','+').replaceAll('_','/');while(s.length%4)s+='=';return Uint8Array.from(atob(s),c=>c.charCodeAt(0))}
export async function hash(p,salt){let k=await crypto.subtle.importKey('raw',enc.encode(p),'PBKDF2',false,['deriveBits']);let bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:120000,hash:'SHA-256'},k,256);return b64(bits)}
export function cookie(name,val,max=604800){return `${name}=${val}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${max}`}
export async function body(request){try{return await request.json()}catch{return {}}}
export async function currentUser(c){let tok=(c.request.headers.get('Cookie')||'').match(/(?:^|;\s*)session=([^;]+)/)?.[1];if(!tok)return null;return await c.env.DB.prepare('SELECT username FROM sessions WHERE token=? AND expires_at>?').bind(tok,Date.now()).first()}
export function admin(c){return (c.request.headers.get('Cookie')||'').split(';').some(x=>x.trim()==='admin=1')}
export {b64,unb64};
