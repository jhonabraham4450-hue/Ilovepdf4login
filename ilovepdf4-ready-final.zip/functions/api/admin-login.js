import {cookie,body} from '../_auth.js';
export async function onRequestPost(c){let x=await body(c.request);if(x.username!==c.env.ADMIN_USER||x.password!==c.env.ADMIN_PASSWORD)return Response.json({ok:false,error:'Admin credentials ভুল'});return new Response(JSON.stringify({ok:true}),{headers:{'Content-Type':'application/json','Set-Cookie':cookie('admin','1')}})}
