import {admin} from '../_auth.js';
export async function onRequestGet(c){if(!admin(c))return Response.json({ok:false},{status:401});let r=await c.env.DB.prepare('SELECT id,username,created_at FROM users ORDER BY id DESC').all();return Response.json({ok:true,users:r.results})}
