import {cookie} from '../_auth.js';
export async function onRequestPost(c){let tok=(c.request.headers.get('Cookie')||'').match(/(?:^|;\s*)session=([^;]+)/)?.[1];if(tok)await c.env.DB.prepare('DELETE FROM sessions WHERE token=?').bind(tok).run();return new Response(JSON.stringify({ok:true}),{headers:{'Content-Type':'application/json','Set-Cookie':cookie('session','',0)}})}
