import {currentUser} from '../_auth.js';
export async function onRequestGet(c){let r=await currentUser(c);return Response.json(r?{ok:true,username:r.username}:{ok:false})}
