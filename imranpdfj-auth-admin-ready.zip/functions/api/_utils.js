const E=new TextEncoder();const b64=b=>btoa(String.fromCharCode(...new Uint8Array(b)));const ub=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0)).buffer;
export async function hashPassword(p,salt=b64(crypto.getRandomValues(new Uint8Array(16)))){let k=await crypto.subtle.importKey('raw',E.encode(p),'PBKDF2',false,['deriveBits']);let x=await crypto.subtle.deriveBits({name:'PBKDF2',salt:ub(salt),iterations:100000,hash:'SHA-256'},k,256);return salt+'.'+b64(x)}
export async function verifyPassword(p,s){let [salt,h]=String(s||'').split('.');return !!salt&&!!h&&(await hashPassword(p,salt)).split('.')[1]===h}
export function json(x,status=200,h={}){return new Response(JSON.stringify(x),{status,headers:{'Content-Type':'application/json',...h}})}
export function cookie(n,v,age=604800){return `${n}=${encodeURIComponent(v)}; Path=/; Max-Age=${age}; HttpOnly; Secure; SameSite=Lax`}
export function clear(n){return cookie(n,'',0)}
export function getCookie(r,n){for(let p of (r.headers.get('Cookie')||'').split(';')){let [k,...v]=p.trim().split('=');if(k===n)return decodeURIComponent(v.join('='))}return null}
export async function body(r){try{return await r.json()}catch{return {}}}
export async function user(r,e){let s=getCookie(r,'sid');return s?e.DB.prepare('SELECT u.id,u.name,u.email,u.phone FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=? AND s.expires_at>?').bind(s,Date.now()).first():null}
export async function admin(r,e){let s=getCookie(r,'admin_sid');return s?!!await e.DB.prepare('SELECT id FROM admin_sessions WHERE id=? AND expires_at>?').bind(s,Date.now()).first():false}